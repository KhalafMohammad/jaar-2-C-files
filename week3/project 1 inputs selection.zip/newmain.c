
// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Reset Selection bits (BOR enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <pic16f887.h>
#define _XTAL_FREQ      500000  // Used by the XC8 delay_ms(x) macro

// LEDs macros
#define LEDQ1   PORTAbits.RA0 
#define LEDQ2   PORTAbits.RA1
#define LEDQ3   PORTAbits.RA2
#define LEDQ4   PORTAbits.RA3


//encoder input pins
#define en_DT   PORTBbits.RB4
#define en_CLK  PORTBbits.RB5

//LED state Macros
#define OFF 1
#define ON 0

// programflow related functions

void encoder_init(uint8_t currentEncoder);

//functions init
void pic_init(void);
void init_osc(void);

//main function
void main(void)
{
    
    // Do all initialisation here
    int pin1;
    int pin2;
    pic_init();

    
    while(1)
    {
        pin1 = en_DT; //set pin status to pin 1
        pin2 = en_CLK; //set pin status to pin 2
        
        uint8_t currentEncoderState = 0; //set de 8bit variable naar 0
        
        currentEncoderState |= (pin1 <<0); // Set de least significante bit naar Pin 1's state 0bf1
        currentEncoderState |= (pin2 <<1); // Set de volgende bit naar Pin 2's state 0b1f
        
        encoder_init(currentEncoderState); //function call
    }
}
void pic_init(void)
{
    OSCCON =    0b00111000;                            //500KHz clock speed
    TRISA =     0b00000000;                              //<RA3:RA0> LEDs pins are outputs
    ANSEL =     0;                                       //init ansel op A  naar digital. 
    TRISB =     0b00110000;                              //set RB4 and RB5 as inputs.
    ANSELH =    0;                                       // set all pins on B I/O to digital
    
    init_osc();
}

void encoder_init(uint8_t currentEncoder){
    
    
    if(currentEncoder == 0b01){//1 pin RB5 is 0 en pin RB4 is 1
            
            LEDQ1 = ON;
            LEDQ2 = OFF;
            LEDQ3 = OFF;
            LEDQ4 = OFF;
        }else if(currentEncoder == 0b11){//2 pin RB5 is 1 en pin RB4 is 1
            
            LEDQ1 = ON;
            LEDQ2 = ON;
            LEDQ3 = OFF;
            LEDQ4 = OFF;
        }else if(currentEncoder == 0b10){//3 pin RB5 is 1 en pin RB4 is 0
            
            LEDQ1 = ON;
            LEDQ2 = ON;
            LEDQ3 = ON;
            LEDQ4 = OFF;
        }else if(currentEncoder == 0b00){//4 pin RB5 is 0 en pin RB4 is 0
            
            LEDQ1 = ON;
            LEDQ2 = ON;
            LEDQ3 = ON;
            LEDQ4 = ON;
        }
}


void init_osc(void)
{
    // Do it like this, it's easily compared to the datasheet:
    // System Clock Select (SCS)
    OSCCONbits.SCS      = 0b00;     // Clk determined by FOSC in Conf-1
    // Internal Resistor-Capacitor Frequency select (IRCF)
    OSCCONbits.IRCF     = 0b011;   // 500 kHz clock speed
}

//interrupt function
void __interrupt() isr();